﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static Part2.username;

namespace Part2
{//start of namespace
    public partial class MainWindow : Window
    {
        //creating an instance for the class Array
        ArrayList reply = new ArrayList();
        ArrayList ignore = new ArrayList();
        username check_name = new username();

        messagedisplay display;
        chatbotlogic bot = new chatbotlogic();
        textprocessing process = new textprocessing();

        // variables
        string username = string.Empty;
        string pre_question = string.Empty;
      

        public MainWindow()
        {
            InitializeComponent();

            // Initialize display with the chats ListView from XAML
            display = new messagedisplay(chats);

            new respond(reply, ignore) { };

            //creating an instance for the class voice_greeting 
            //with an object name greet
            voice_greeting greet = new voice_greeting();

            //call the voice method
            greet.greet();
        }

        //proceed  event handler
        private void proceed(object sender, RoutedEventArgs e)
        {
            //Hide home page grid and set Username grid visible
            home_grid.Visibility = Visibility.Hidden;
            username_grid.Visibility = Visibility.Visible;
        }

        //submit name  event handler
        private void submit_name(object sender, RoutedEventArgs e)
        {//start of submit name event handler

            // Check the user name from memory recall
            string result = check_name.submit_name(usernames_input, chats, UsernameErrorMessage);

            if (result != null)
            {
                username = result;

                //Hide username page grid and set chats grid visible
                username_grid.Visibility = Visibility.Hidden;
                chat_grid.Visibility = Visibility.Visible;
            }
        }

        //send event handler
        private void send(object sender, RoutedEventArgs e)
        {
            // Get the question from the design and sanitize it
            string rawQuestion = question.Text.ToString().Trim();

            if (string.IsNullOrWhiteSpace(rawQuestion))
            {
                display.error_method("ChatBot", "Please enter a question.");
                return;
            }

            // Show what the user typed in the chat
            display.error_method(username, rawQuestion);


            // Show what the user typed 
            // Remove special characters and clean the question
            string questions = process.RemoveSpecialCharacters(rawQuestion);

            // Check if question is empty after cleaning
            if (string.IsNullOrWhiteSpace(questions))
            {
                display.error_method("ChatBot", "I couldn't understand that. Please use words and letters only.");
                question.Clear();
                return;
            }

            // Process the question with the chatbot logic
            bot.ai_check(questions, reply, ignore, display, chats, question, username);



        }//end for the username submit

        private void question_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                send(sender, e);
            }
        }




    }//  end of class
}// end of namespace
